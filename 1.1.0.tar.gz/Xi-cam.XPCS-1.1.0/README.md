XPCS
===============================

version number: 
author: Ron Pandolfi

Overview
--------

XPCS GUI interface

Installation / Usage
--------------------

To install use pip:

    $ pip install XPCS


Or clone the repo:

    $ git clone 
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD
